include.module( 'projections', [ 'proj4' ], function () {
    "use strict";

    proj4.defs( "urn:ogc:def:crs:EPSG::3005", "+proj=aea +lat_1=50 +lat_2=58.5 +lat_0=45 +lon_0=-126 +x_0=1000000 +y_0=0 +ellps=GRS80 +datum=NAD83 +units=m +no_defs" )
} )